var structCam =
[
    [ "fx", "structCam.html#a7d82658b0f9a7df54516cffb6d67ac07", null ],
    [ "fy", "structCam.html#a2c80b4688fa8d02ad6c645246b6ea0d4", null ],
    [ "ppx", "structCam.html#a0d44db9d2a2e8c416cbf9cd30b6cd6f1", null ],
    [ "ppy", "structCam.html#a5af4cee2ad3b008befb9626990dfbff2", null ],
    [ "Q_TD", "structCam.html#a8b6ed5501753ad64cf3e36f798fbf3cd", null ],
    [ "scale", "structCam.html#a99a4c54ed1a408665a0963f308008ec8", null ],
    [ "T_TD", "structCam.html#a05f5a946647cd44a473b0fd03186ca96", null ]
];