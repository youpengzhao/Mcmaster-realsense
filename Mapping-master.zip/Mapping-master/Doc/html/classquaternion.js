var classquaternion =
[
    [ "quaternion", "classquaternion.html#a01adb7930c2003b777cb91a7182c482e", null ],
    [ "quaternion", "classquaternion.html#a7939abaec2de1b11ff2208cbd8fbd93e", null ],
    [ "inv", "classquaternion.html#a52cd9cd03bc2613e56dd798cb1037a51", null ],
    [ "inv", "classquaternion.html#a5f2dff4e0f446d05e826a63d5a45d230", null ],
    [ "operator*", "classquaternion.html#a444a0e12b77a4388d496de9210117786", null ],
    [ "operator*", "classquaternion.html#a63777bf9c0c0a269852808442c2be4f5", null ],
    [ "operator+", "classquaternion.html#a5def90b88f02a02961ff51d6cd3e7dae", null ],
    [ "operator+", "classquaternion.html#ae2cf533c781610bf66bf39c30bd6b6ec", null ],
    [ "w", "classquaternion.html#ab2b38aca1971114e0ba4218b75d7f472", null ],
    [ "x", "classquaternion.html#acdcda48f9dd7ff35873aae38fa33ab78", null ],
    [ "y", "classquaternion.html#a48e3d1fbf5e12eb54985c32b45dd8303", null ],
    [ "z", "classquaternion.html#a538598007238d399f79ddcecd39ef5cf", null ]
];