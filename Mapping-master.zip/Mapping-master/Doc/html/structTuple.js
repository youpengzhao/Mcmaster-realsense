var structTuple =
[
    [ "c", "structTuple.html#a69871fb52122a48baa140565fb1b7c0c", null ],
    [ "x", "structTuple.html#a9355c336c18afa6b76685ddffe16c5a5", null ],
    [ "y", "structTuple.html#ae298b0277eb33e02696b6e3716e93c46", null ],
    [ "z", "structTuple.html#a5f83aeb6b110bc956fd27b8e713a9ad5", null ]
];