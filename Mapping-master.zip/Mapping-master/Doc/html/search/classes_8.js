var searchData=
[
  ['tuple',['Tuple',['../structTuple.html',1,'']]]
];
