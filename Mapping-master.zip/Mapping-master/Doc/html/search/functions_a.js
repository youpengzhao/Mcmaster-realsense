var searchData=
[
  ['quaternion',['quaternion',['../classquaternion.html#a01adb7930c2003b777cb91a7182c482e',1,'quaternion::quaternion(float x, float y, float z, float w)'],['../classquaternion.html#a7939abaec2de1b11ff2208cbd8fbd93e',1,'quaternion::quaternion(float x, float y, float z, float w)']]]
];
