var indexSectionsWithContent =
{
  0: "_abcdfghilmnopqrstuvwxyz~",
  1: "bcglmopqtv",
  2: "cghlv",
  3: "abcfgilmopquv~",
  4: "_bcdfghilmpqrstvwxyz",
  5: "bcimnv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros"
};

