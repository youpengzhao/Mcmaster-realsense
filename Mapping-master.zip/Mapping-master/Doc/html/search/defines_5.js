var searchData=
[
  ['var_5fp',['VAR_P',['../Voxel_8cuh.html#ae1cd6283839fc3aebf9bccbd1044a365',1,'VAR_P():&#160;Voxel.cuh'],['../Voxel_8hpp.html#ae1cd6283839fc3aebf9bccbd1044a365',1,'VAR_P():&#160;Voxel.hpp']]],
  ['vox_5fl',['VOX_L',['../Voxel_8cuh.html#a3c1c8b966e30fa8ca2de07abe3b3d74a',1,'VOX_L():&#160;Voxel.cuh'],['../Voxel_8hpp.html#a3c1c8b966e30fa8ca2de07abe3b3d74a',1,'VOX_L():&#160;Voxel.hpp']]],
  ['voxel_5fch',['VOXEL_CH',['../Voxel_8cuh.html#aca76098e63473a0423c740cd04ec72b8',1,'Voxel.cuh']]]
];
