var searchData=
[
  ['y',['y',['../classquaternion.html#a48e3d1fbf5e12eb54985c32b45dd8303',1,'quaternion::y()'],['../structTuple.html#ae298b0277eb33e02696b6e3716e93c46',1,'Tuple::y()'],['../structPoint.html#a6101960c8d2d4e8ea1d32c9234bbeb8d',1,'Point::y()']]],
  ['y_5fv',['y_v',['../classleaf.html#a06a94d40da44b846913db4d8900b2626',1,'leaf::y_v()'],['../classvoxel.html#a67b339eef4ce4330a18d15973dcf6a24',1,'voxel::y_v()']]]
];
