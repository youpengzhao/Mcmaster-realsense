var searchData=
[
  ['num_5fb',['NUM_B',['../Voxel_8cuh.html#a9f984157d0b56c37dfb4bd1a16f1e8ab',1,'Voxel.cuh']]],
  ['num_5ft',['NUM_T',['../Voxel_8cuh.html#ad8ba90b2d681fcfbc6cde44271ad6519',1,'Voxel.cuh']]]
];
