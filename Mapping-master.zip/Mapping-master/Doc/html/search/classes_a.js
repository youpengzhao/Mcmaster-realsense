var searchData=
[
  ['writer',['Writer',['../classWriter.html',1,'']]]
];
