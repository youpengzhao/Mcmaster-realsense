var searchData=
[
  ['v_5flogging',['v_logging',['../Logging_8hpp.html#adaf32a6a0736e8e3da49a3c2b0705fa7',1,'Logging.hpp']]]
];
