var searchData=
[
  ['logging_2ehpp',['Logging.hpp',['../Logging_8hpp.html',1,'']]]
];
