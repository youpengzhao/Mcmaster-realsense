var searchData=
[
  ['voxel',['voxel',['../classvoxel.html#a1f832fd40f23c4fd721a4144387db6ef',1,'voxel::voxel(float x, float y, float z, float size)'],['../classvoxel.html#a77f20a6fddec8f3aa3c719c3dc609948',1,'voxel::voxel(float x, float y, float z, float size)']]]
];
