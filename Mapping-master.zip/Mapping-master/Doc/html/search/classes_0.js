var searchData=
[
  ['bool_5finit',['Bool_Init',['../structBool__Init.html',1,'']]]
];
