var searchData=
[
  ['all_5fpoints',['all_points',['../classvoxel.html#a4189fb0f24ad9eba1447e2ebf8ee0015',1,'voxel::all_points(Tuple *set, float x_o, float y_o, float z_o, int *idx)'],['../classvoxel.html#aaea83372a2e28b25ae65dcc635ebe635',1,'voxel::all_points(std::vector&lt; std::tuple&lt; float, float, float, float &gt; &gt; *set, float x_o, float y_o, float z_o)'],['../classocc__grid.html#a8b47af213fb57bf31c21ab1a9ef36505',1,'occ_grid::all_points()']]]
];
