var searchData=
[
  ['leaf',['leaf',['../classleaf.html#adfaf04cd4b50545cbc902d1aa36bc609',1,'leaf::leaf(float x, float y, float z)'],['../classleaf.html#aafe906fcbc78cef65683b3015de636bd',1,'leaf::leaf(float x, float y, float z)']]],
  ['log',['Log',['../classLogger.html#adcc95257ff2edceded8e272dac3603ce',1,'Logger']]],
  ['logger',['Logger',['../classLogger.html#abc41bfb031d896170c7675fa96a6b30c',1,'Logger']]]
];
