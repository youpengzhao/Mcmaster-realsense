var searchData=
[
  ['buf',['buf',['../classLogger.html#a0fd4efa39e08c0253f59f76e08abefee',1,'Logger']]]
];
