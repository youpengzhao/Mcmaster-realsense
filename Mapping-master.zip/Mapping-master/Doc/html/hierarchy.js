var hierarchy =
[
    [ "Bool_Init", "structBool__Init.html", null ],
    [ "Cam", "structCam.html", null ],
    [ "Camera", "classCamera.html", null ],
    [ "leaf", "classleaf.html", null ],
    [ "Logger", "classLogger.html", null ],
    [ "Map_FE", "classMap__FE.html", [
      [ "CPU_FE", "classCPU__FE.html", null ],
      [ "GPU_FE", "classGPU__FE.html", null ]
    ] ],
    [ "occ_grid", "classocc__grid.html", null ],
    [ "Pair< A, B >", "classPair.html", null ],
    [ "Pair< long, Pair< voxel *, Point > >", "classPair.html", null ],
    [ "Point", "structPoint.html", null ],
    [ "Pose", "structPose.html", null ],
    [ "quaternion", "classquaternion.html", null ],
    [ "Tuple", "structTuple.html", null ],
    [ "voxel", "classvoxel.html", null ]
];