var classCamera =
[
    [ "Camera", "classCamera.html#a01f94c3543f56ede7af49dc778f19331", null ],
    [ "Init", "classCamera.html#a7f09b843d9b3a97e78eefcebbc53e054", null ],
    [ "coeffs", "classCamera.html#af6b42da84223170eb6434a3df1d677af", null ],
    [ "ctx", "classCamera.html#a4373bc8793e3bb1d6eb2cca3eb25a31e", null ],
    [ "d_queue", "classCamera.html#a84a3a043e61b967fb1dc6fbe62bf33aa", null ],
    [ "fx", "classCamera.html#a4f5e789525c1c9306028c080922582e2", null ],
    [ "fy", "classCamera.html#a1472650e23f3df5f23dda7f94537e889", null ],
    [ "model", "classCamera.html#a3061c56d262cab256468f05b9d8838fc", null ],
    [ "pipelines", "classCamera.html#a689d4141375d8f7fbf1651338c1ea9c0", null ],
    [ "ppx", "classCamera.html#aa646a2de04e9ad37395dcf3c4a171abe", null ],
    [ "ppy", "classCamera.html#a0e51f157264b9c9e18feb584c5a6c606", null ],
    [ "scale", "classCamera.html#a50152f7c8f2ce7601dd6086c90b3a65c", null ],
    [ "t_queue", "classCamera.html#ad8a4c52c0ae125ab8ca66902408f5e95", null ]
];