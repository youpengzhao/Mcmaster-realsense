var structBool__Init =
[
    [ "d435", "structBool__Init.html#a9b59846a335953ae88cad02cd9cf9b34", null ],
    [ "t265", "structBool__Init.html#a28c7d578113b5a52c1706c10be8fe6c6", null ]
];