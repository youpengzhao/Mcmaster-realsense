var structPoint =
[
    [ "x", "structPoint.html#a05dfe2dfbde813ad234b514f30e662f1", null ],
    [ "y", "structPoint.html#a6101960c8d2d4e8ea1d32c9234bbeb8d", null ],
    [ "z", "structPoint.html#a9a666531e0e99adff132be93d2407d0c", null ]
];